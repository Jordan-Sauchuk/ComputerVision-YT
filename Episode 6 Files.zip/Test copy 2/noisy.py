#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 11:26:51 2019

@author: jordansauchuk
"""


from PIL import Image
import pytesseract
from wand.image import Image as Img
import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
import numpy as np

#####


demo = Image.open("example_two_shift copy.png")
text = pytesseract.image_to_string(demo, lang = 'eng')
print(text)



##### - black and white


image_file = Image.open("color_test.png")
image_file = image_file.convert('1') 
image_file.save('color_black_and_white.png')


