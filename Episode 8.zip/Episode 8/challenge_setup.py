#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  5 13:04:16 2019

@author: jordansauchuk
"""




1. OCR

2. Tokenize

3. FreqDist

4. Plot


