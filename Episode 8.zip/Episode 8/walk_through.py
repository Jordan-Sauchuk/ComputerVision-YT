#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 10:38:23 2019

@author: jordansauchuk
"""

from PIL import Image
import pytesseract
from wand.image import Image as Img
import nltk
#import numpy as np

# Part 1 : OCR

demo_one = Image.open("example.png")
text_one = pytesseract.image_to_string(demo_one, lang = 'eng')
print(text_one)


demo_two = Image.open("receipt.png")
text_two = pytesseract.image_to_string(demo_two, lang = 'eng')
print(text_two)


# Part 2: Tokenize 


from nltk.tokenize import word_tokenize

tokenized_word_one=word_tokenize(text_one)
print(tokenized_word_one)

tokenized_word_two=word_tokenize(text_two)
print(tokenized_word_two)


# Part 3: FreqDist

from nltk.probability import FreqDist

f_dist_one = FreqDist(tokenized_word_one)
f_dist_two = FreqDist(tokenized_word_two)

f_dist_one.most_common(10)


# Part 4: Plot


df_one = f_dist_one.most_common(10)



import plotly.plotly as py
import plotly.graph_objs as go
from plotly.offline import plot

import pandas as pd
import numpy as np


data = [
    go.Scatter(
        x=df[0], # assign x as the dataframe column 'x'
        y=df[1]
    )
]
plot(data)



import matplotlib.pyplot as plt
f_dist_two.plot(20,cumulative=False)
plt.show()


f_dist_one.plot(20,cumulative=False)
plt.show()





