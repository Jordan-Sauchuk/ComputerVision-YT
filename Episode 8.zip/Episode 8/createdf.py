#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  7 12:52:13 2019

@author: jordansauchuk
"""

import pandas as pd

from PIL import Image
import pytesseract
from wand.image import Image as Img
import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
import numpy as np



df = pd.read_csv('demodf.txt', sep=" ", header=None, names=['a', 'b', 'c',])
print(df)

dataset = pd.read_csv('demodf.txt', delimiter="\t")
print(dataset)
dataset.head(10)




demo = Image.open("/receipt.png")
text = pytesseract.image_to_string(demo, lang = 'eng')
print(text)
